﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using _200367201F.Models;

namespace _200367201F.Controllers
{
    public class ChatAppsController : ApiController
    {
        private _200367201FContext db = new _200367201FContext();

        // GET: api/ChatApps
        public IQueryable<ChatApp> GetChatApps()
        {
            return db.ChatApps;
        }

        // GET: api/ChatApps/5
        [ResponseType(typeof(ChatApp))]
        public IHttpActionResult GetChatApp(int id)
        {
            ChatApp chatApp = db.ChatApps.Find(id);
            if (chatApp == null)
            {
                return NotFound();
            }

            return Ok(chatApp);
        }

        // PUT: api/ChatApps/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutChatApp(int id, ChatApp chatApp)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != chatApp.ID)
            {
                return BadRequest();
            }

            db.Entry(chatApp).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ChatAppExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/ChatApps
        [ResponseType(typeof(ChatApp))]
        public IHttpActionResult PostChatApp(ChatApp chatApp)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.ChatApps.Add(chatApp);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = chatApp.ID }, chatApp);
        }

        // DELETE: api/ChatApps/5
        [ResponseType(typeof(ChatApp))]
        public IHttpActionResult DeleteChatApp(int id)
        {
            ChatApp chatApp = db.ChatApps.Find(id);
            if (chatApp == null)
            {
                return NotFound();
            }

            db.ChatApps.Remove(chatApp);
            db.SaveChanges();

            return Ok(chatApp);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool ChatAppExists(int id)
        {
            return db.ChatApps.Count(e => e.ID == id) > 0;
        }
    }
}