﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace _200367201F.Models
{
    public class ChatApp
    {
        
        public virtual int ID { get; set; }
        [Required]
        public virtual String Message { get; set; }
        [Required]
        public virtual String Name { get; set; }
        public virtual DateTime PostedAd { get; set; }
    }
}